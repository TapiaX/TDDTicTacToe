package tictactoe.frontend;

public interface ITicTacToeUI {
    public void run();
}
